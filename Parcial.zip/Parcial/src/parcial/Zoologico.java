
package parcial;

import java.util.ArrayList;


public class Zoologico {
    private String nombre;
    ArrayList<Animal> animales;
    
    public Zoologico(String nombre){
        this.nombre = nombre;
        animales = new ArrayList<>();
    }
    
    /*- agregarAnimal() : El empleado del zoológico debe poder agregar todo tipo de animales al mismo. Se deberá
    lanzar una excepción personalizada si ya existe el animal. (dos animales son iguales si tienen el mismo nombre
    y la misma edad)*/
    
    //metodo para verificar que el animal no se encuentre ya en la lista
    public void verificarAnimalRepetido(Animal a){
        if(animales.contains(a)){ //el animal debe tener la misma edad y el mismo nombre para que se valide como repetido
            throw new animalRepetidoException(); //se arroja una excepcion
        }
    }
    
    public void agregarAnimal(Animal a){
        verificarAnimalRepetido(a);
        if(a!=null){
            animales.add(a);
        }
    }
    
    /*- mostrarAnimales() : Muestra todos los animales donde se pueden observar los siguientes
    atributos.(dedúzcalos de la imagen de ejemplo):*/
    
    public void mostrarAnimales(){
        for(Animal animal: animales){
            System.out.println(animal.toString());
        }
    }
}
