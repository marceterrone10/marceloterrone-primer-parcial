/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial;

/**
 *
 * @author marce
 */
public class animalRepetidoException extends RuntimeException {
    public static final String MESSAGE = "Ya existe un animal con el mismo nombre y edad";
    
    public animalRepetidoException() {
        super(MESSAGE);
    }
    
}
