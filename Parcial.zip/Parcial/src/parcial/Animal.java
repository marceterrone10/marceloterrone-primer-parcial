/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial;

/**
 *
 * @author marce
 */
public abstract class Animal {
    private String nombre;
    private int edad;
    private double peso;
    private TipoDieta tipoDieta;

    public Animal(String nombre, int edad, double peso, TipoDieta tipoDieta) {
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;
        this.tipoDieta = tipoDieta;
    }

    public TipoDieta getTipoDieta() {
        return tipoDieta;
    }

    public double getPeso(){
        return peso;
    }
    
    public String getNombre(){
        return nombre;
    }
    public int getEdad(){
        return edad;
    }
   

    @Override
    public abstract String toString();

    @Override
    public boolean equals(Object o){
        if(this==o){
            return true;
        }
        if(o==null || o.getClass() != this.getClass()){
            return false;
        }
        Animal animal = (Animal) o;
        return nombre.equals(animal.nombre) && edad == animal.edad;
    }
    
    
    
}
