/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial;

/**
 *
 * @author marce
 */
public class Mamiferos extends Animal implements Vacunable {
    
    public Mamiferos(String nombre, int edad, double peso, TipoDieta tipoDieta) {
        super(nombre, edad, peso, tipoDieta);
    }
   

    @Override
    public String toString() {
        return "Mamiferos{" + "Peso: " + getPeso() + ", dieta: " + getTipoDieta() + '}';
    }

    @Override
    public void vacunar() {
        System.out.println("El mamifero: " + getNombre() + " se ha vacunado");
    }
    
    
    
    
}
