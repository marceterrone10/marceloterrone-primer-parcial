/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial;

/**
 *
 * @author marce
 */
public class Reptiles extends Animal{
    
    private String tipoEscama;
    private String regulacionTemp;

    public Reptiles(String nombre, int edad, double peso, TipoDieta tipoDieta, String tipoEscama, String regulacionTemp) {
        super(nombre, edad, peso, tipoDieta);
        this.tipoEscama = tipoEscama;
        this.regulacionTemp = regulacionTemp;
    }
    

    @Override
    public String toString() {
        return "Reptiles{" + "tipoEscama=" + tipoEscama + ", regulacionTemp=" + regulacionTemp + '}';
    }

    
    public void vacunar() {
        throw new animalNoVacunableException();
    }
    
    
    
}
