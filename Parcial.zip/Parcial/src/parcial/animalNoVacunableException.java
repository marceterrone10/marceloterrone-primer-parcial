/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial;

/**
 *
 * @author marce
 */
public class animalNoVacunableException extends RuntimeException {
    public static final String MESSAGE = "El animal no es vacunable";
    public animalNoVacunableException() {
        super(MESSAGE);
    }
    
}
