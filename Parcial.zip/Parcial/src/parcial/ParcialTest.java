/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package parcial;

/**
 *
 * @author marce
 */
public class ParcialTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Zoologico zoo = new Zoologico("UTN");
        Mamiferos m1 = new Mamiferos("Marcelo", 20, 80, TipoDieta.CARNIVORO);
        Aves a1 = new Aves("Pepe", 2, 10, TipoDieta.HERBIVORO, 54.7);
        Aves a2 = new Aves("Pedro", 4, 10, TipoDieta.HERBIVORO, 47.0);
        Reptiles r1 = new Reptiles("Bicho", 5, 10, TipoDieta.OMNIVORO, "queratinosa", "ecotermia");
        Mamiferos m2 = m1;
        Reptiles r2 = r1;
        
        //vacunando animales
        try{
            m1.vacunar();
        }
        catch(animalNoVacunableException e){
            System.out.println(e.getMessage());
        }
        
        try{
            a1.vacunar();
        }
        catch(animalNoVacunableException e){
            System.out.println(e.getMessage());
        }  
        
        try{
            r1.vacunar();
        }
        catch(animalNoVacunableException e){
            System.out.println(e.getMessage());
        }
        System.out.println("-----------------------------------------------------");
        
        //agregar animales a la lista
        try{
            zoo.agregarAnimal(m1);
            System.out.println("Se agrego el animal correctamente");
        }
        catch(animalRepetidoException e){
            System.out.println(e.getMessage());
        }

        try{
            zoo.agregarAnimal(m2); //esperable excepcion porque se repite
        }
        catch(animalRepetidoException e){
            System.out.println(e.getMessage());
        }
        
        try{
            zoo.agregarAnimal(a1);
            zoo.agregarAnimal(a2);
            System.out.println("Se agrego el animal correctamente");
        }
        catch(animalRepetidoException e){
            System.out.println(e.getMessage());
        }
        
        try{
            zoo.agregarAnimal(r1);
            System.out.println("Se agrego el animal correctamente");
        }
        catch(animalRepetidoException e){
            System.out.println(e.getMessage());
        }
        
        try{
            zoo.agregarAnimal(r1);
            System.out.println("Se agrego el animal correctamente");
        }
        catch(animalRepetidoException e){
            System.out.println(e.getMessage());
        }
        
        System.out.println("--------------------------------------------------------");
        
        zoo.mostrarAnimales();


    }
    
}
