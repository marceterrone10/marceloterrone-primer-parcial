/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial;

/**
 *
 * @author marce
 */
public class Aves extends Animal implements Vacunable{
    
    private double envergaduraAlas;

    public Aves(String nombre, int edad, double peso, TipoDieta tipoDieta, double envergaduraAlas) {
        super(nombre, edad, peso, tipoDieta);
        this.envergaduraAlas = envergaduraAlas;
    }

    @Override
    public String toString() {
        return "Aves{" + "envergaduraAlas=" + envergaduraAlas + '}';
    }

    @Override
    public void vacunar() {
        System.out.println("El ave: " + getNombre() + " se ha vacunado");
    }
    
    
    
}
